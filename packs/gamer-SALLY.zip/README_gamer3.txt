Gamer theme for Saly (private, 4 colours: yellow, purple, pink, white). Name on the files: SALLY. Each piece: .3mf (Bambu Studio, AMS colours set), .stl, per-colour STLs, preview PNG.
Another name: python student_pack/generate.py --name NAME --theme gamer_girl
Personal use only: the art contains Roblox-style logos.
