Gamer theme for Sally (private, 4 colours: black, pink, purple, white). Name on the files: SALLY. Each piece: .3mf (Bambu Studio, AMS colours set), .stl, per-colour STLs, preview PNG.
Another name: python student_pack/generate.py --name NAME --theme gamer
Personal use only: the art contains Roblox-style logos.
