APPROVED: Gamer theme for Saly, 4 colours (yellow, purple, pink, white), upscaled GPT sheet (1911 x 2000). Name on the files: SALLY.
Each piece: .3mf (Bambu Studio, AMS colours set), .stl, per-colour STLs, preview PNG.
Another name: python student_pack/generate.py --name NAME --theme gamer_girl7
Personal use only: the art contains Roblox-style logos.
