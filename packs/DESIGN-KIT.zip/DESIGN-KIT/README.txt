DESIGN KIT (3D ZONE TECH) - turn a character picture into a printable student pack
The example in /example is Osayd's pack:
  1_example_sheet_for_GPT.png  = the GPT sheet that worked (the design we traced) (tag, bottle tag, pencil strip, ruler)
  2_example_printed_result.png = what the printer file looks like from that sheet
  3_example_flat_4colours_conversion.png = the same sheet converted to exactly 4 flat colours (what the printer sees)

Steps: 1) read 3_HOW_TO_PICK... 2) use 1_PROMPT (EN) or 2_PROMPT (AR) with GPT 3) send the result sheet to Claude.
Note: registered characters (Disney, Sanrio, Nintendo...) are for personal gifts only, never for sale or ads.
