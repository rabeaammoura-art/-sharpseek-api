Gamer theme for Saly, 3 colours (yellow, pink, white), redrawn by GPT for 3 flat colours. Name on the files: SALLY.
Each piece: .3mf (Bambu Studio, AMS colours set), .stl, per-colour STLs, preview PNG.
Another name: python student_pack/generate.py --name NAME --theme gamer_girl3
Personal use only: the art contains Roblox-style logos.
