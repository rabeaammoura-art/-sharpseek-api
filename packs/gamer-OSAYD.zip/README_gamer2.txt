Gamer theme for Osayd (private, 4 colours: black, blue, red, white). Name on the files: OSAYD. Each piece: .3mf (Bambu Studio, AMS colours set), .stl, per-colour STLs, preview PNG.
Another name: python student_pack/generate.py --name NAME --theme gamer
Personal use only: the art contains Roblox-style logos.
