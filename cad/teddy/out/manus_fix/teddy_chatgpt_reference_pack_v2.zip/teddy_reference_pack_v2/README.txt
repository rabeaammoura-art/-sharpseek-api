Reference pack for ChatGPT image generation.
Renders 01-07 are made from the current STL files (fixed version: teddy_body_chest_led_v3.stl + chest_heart_lid_v3.stl).
Note: the LED recess depth and the smoothness of the pocket (visible only with the lid removed) are still being fixed by Manus;
they do not change the outside of the assembled bear.
Upload the PNG/JPG files together with the text in PROMPT_for_ChatGPT.txt.
AI images are illustrative only: they are not dimensionally exact.
